from flask import Flask, request, render_template
import joblib
import numpy as np
import os
import logging

app = Flask(__name__, template_folder=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'template'))

# Set up logging to a file for predictions only
prediction_logger = logging.getLogger('prediction_logger')
prediction_logger.setLevel(logging.INFO)
file_handler = logging.FileHandler('prediction_log.txt')
file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
prediction_logger.addHandler(file_handler)

# Get the directory of the current script (app.py)
script_dir = os.path.dirname(os.path.abspath(__file__))
model_path = os.path.join(script_dir, 'student-performance.joblib')

# Debug paths
# print("Current script directory:", script_dir)
# print("Model path:", model_path)

# Load the trained model
try:
    model = joblib.load(model_path)
    print("Model loaded successfully.")
except Exception as e:
    print(f"Error loading model: {str(e)}")
    raise e

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get user input from the form/index.html
        user_input = [float(x) for x in request.form.values()]
        prediction_logger.info(f"User Input: {user_input}")
        
        # Ensure input is in the right shape (2D array)
        input_array = np.array(user_input).reshape(1, -1)
        prediction_logger.info(f"Input array for prediction: {input_array}")
        
        # Make prediction
        prediction = model.predict(input_array)
        prediction_logger.info(f"Prediction result: {prediction}")
        
        # Return result
        return render_template('index.html', predictions=f"Performance Index: {prediction[0]:.2f}")
    
    except Exception as e:
        # Log the error and display it on the page
        prediction_logger.error(f"Error during prediction: {str(e)}")
        return render_template('index.html', predictions=f"Error: {str(e)}")

if __name__ == '__main__':
    app.run(debug=True)